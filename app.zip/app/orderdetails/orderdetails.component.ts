import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NodeUtilityService } from '../node-utility.service';

@Component({
  selector: 'app-orderdetails',
  templateUrl: './orderdetails.component.html',
  styleUrls: ['./orderdetails.component.css']
})
export class OrderdetailsComponent implements OnInit {
  selectedUsername: string = '';
  usernames: string[] = [];
  orderDetails: any[] = [];
  errorMessage: string = '';
  msg: string = '';

  constructor(private http: HttpClient, private util: NodeUtilityService) {}

  ngOnInit(): void {
    // Fetch usernames when the component initializes
    this.util.getUsernames().subscribe((data) => {
      if (data.status) {
        this.usernames = data.usernames;
      } else {
        console.error('Failed to fetch usernames:', data.message);
      }
    });
  }

  findOrderDetails(): void {
    this.errorMessage = ''; // Reset error message
    if (!this.selectedUsername) {
      this.errorMessage = 'Please select a username.';
      return;
    }

    // Call the 'find' method with the 'selectedUsername' parameter
    this.util.find(this.selectedUsername).subscribe((data) => {
      if (data.status) {
        this.orderDetails = data.orderDetails;
      } else {
        this.errorMessage = data.message; // Handle error message
      }
      this.msg = data.message;
      console.log(this.msg);
    }, (error) => {
      this.errorMessage = 'Failed to retrieve order details'; // Handle HTTP error
      console.error('HTTP Error:', error);
    });
  }
}
