import { Component, OnInit } from '@angular/core';
import { NodeUtilityService } from '../node-utility.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
  username: string | null = ''; 
  userDetails: any;
  constructor(private util: NodeUtilityService) { }

  ngOnInit(): void {
    const storedUsername = localStorage.getItem("user");
    this.username = storedUsername !== null ? storedUsername : '';
    

    if (this.username !== '') {
      this.util.finduser(this.username).subscribe((data) => {
        if (data.status) {
          this.userDetails = data.userDetails; // Store user details
          console.log(this.userDetails);
        } else {
          console.log("Failed to fetch user details");
        }
      });
    }
  }
}
