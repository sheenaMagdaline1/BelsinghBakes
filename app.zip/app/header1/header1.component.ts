import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header1',
  templateUrl: './header1.component.html',
  styleUrl: './header1.component.css'
})
export class Header1Component {
  constructor(private router: Router) { }
  admin:string|null="";
  user:string|null="";

  ngOnInit(): void {
   this.user=localStorage.getItem('user');
    this.admin=localStorage.getItem('admin');
     if(this.admin==null||this.user!=null){
      this.router.navigateByUrl('/login');
     } 
}
logout() {
  // Other logout logic
  localStorage.removeItem('admin');
  this.router.navigateByUrl('/login'); // Adjust the route accordingly

}
}