import { MyhighlightDirective } from './myhighlight.directive';

describe('MyhighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new MyhighlightDirective();
    expect(directive).toBeTruthy();
  });
});
