import { Injectable } from '@angular/core';
import { AbstractControl, ValidatorFn, ValidationErrors } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ValidatorsService {

  constructor() { }

  starsValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const stars = control.value;
      return stars >= 0 && stars <= 5 ? null : { starsRange: true };
    };
  }

  priceCentsValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const priceCents = control.value;
      return priceCents >= 0 && priceCents <= 10000 ? null : { priceRange: true };
    };
  }

}
