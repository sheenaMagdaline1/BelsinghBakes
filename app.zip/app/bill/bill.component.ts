import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CartService } from '../cart.service';
import { ActivatedRoute, Router } from '@angular/router';
import { jsPDF } from "jspdf";
import html2canvas from 'html2canvas';
import { Location } from '@angular/common';
import QRCode from 'qrcode-generator';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {
  
  @ViewChild('billPage') billPage!: ElementRef;
zip : string  ='';
  qrCodeImage: string | null = null;
  qrCodeVersion: number = 10;
  cartItems: any[] = [];
  user: string | null = "";
  totalPrice: number = 0;
  shippingAddress: any = {}; // Object to hold shipping address data
  selectedShippingMethod: string = 'standard';
  asianCountries: string[] = [
    'Afghanistan', 'Armenia', 'Azerbaijan', 'Bahrain', 'Bangladesh', 'Bhutan', 'Brunei', 'Cambodia',
    'China', 'Cyprus', 'Georgia', 'India', 'Indonesia', 'Iran', 'Iraq', 'Israel', 'Japan', 'Jordan',
    'Kazakhstan', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Lebanon', 'Malaysia', 'Maldives', 'Mongolia',
    'Myanmar (Burma)', 'Nepal', 'North Korea', 'Oman', 'Pakistan', 'Palestine', 'Philippines', 'Qatar',
    'Saudi Arabia', 'Singapore', 'South Korea', 'Sri Lanka', 'Syria', 'Taiwan', 'Tajikistan', 'Thailand',
    'Timor-Leste', 'Turkey', 'Turkmenistan', 'United Arab Emirates', 'Uzbekistan', 'Vietnam', 'Yemen','Mauritius'
  ];

  constructor(private cartService: CartService, private route: ActivatedRoute, private router: Router,private location: Location) {     
  }

  ngOnInit(): void {
    this.user = localStorage.getItem('user');
    console.log(this.user);
    if (this.user == null) {
      this.router.navigateByUrl('/login');
    }

    // Calculate total price
    this.totalPrice = this.getTotalPrice();
    this.cartItems = this.cartService.loadCartItemsFromLocalStorage();
  }
  getCurrentURL(): string {
    return this.location.path();
  }
  getCurrentDate(): string {
    const currentDate = new Date();
    return currentDate.toISOString().split('T')[0];
  }
  getShippingPrice() {
    let shippingPrice = 0;
  
    // Calculate shipping price based on selected shipping method
    if (this.selectedShippingMethod === 'fast') {
      shippingPrice = 500;
    } else if (this.selectedShippingMethod === 'standard') {
      shippingPrice = 200;
    }
  
    return shippingPrice;
  }
  
  generateQRCode(): void {
    // Calculate the discounted total price
    const total = this.getTotalPrice();
    const discount = total * 0.2; // 20% discount
    const discountedTotal = total - discount;
  
    // Create QR code with the discounted total
    const qrCode = QRCode(0, 'H');
    qrCode.addData(`Discounted Total: Rs.${discountedTotal}`);
    qrCode.make();
    const qrCodeImage = qrCode.createDataURL(10); // Change the size factor as needed
  
    // Set qrCodeImage to display in the template
    this.qrCodeImage = qrCodeImage;
  }
  
  getCurrentTime(): string {
    const currentTime = new Date();
    return currentTime.toTimeString().split(' ')[0];
  }

  getTotalPrice() {
    let totalPrice = 0;
    let shippingPrice = 0; // Variable to store shipping price

    // Calculate total price based on cartItems
    for (const item of this.cartItems) {
      totalPrice += item.total;
    }

    // Calculate shipping price based on selected shipping method
    if (this.selectedShippingMethod === 'fast') {
      shippingPrice = 500;
    } else if (this.selectedShippingMethod === 'standard') {
      shippingPrice = 200;
    }

    // Add shipping price to total price
    totalPrice += shippingPrice;

    return totalPrice;
  }
  
  generatePDF(): void {
    const docDefinition:any = document.getElementById("container");
    html2canvas(docDefinition,{scale:2}).then((canvas)=>{
      const imgData = canvas.toDataURL('image/png');
      const imgWidth = 208;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      const pdf= new jsPDF();
      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.setProperties({
        title:'my page',
        subject:'pdf from html',
        author:'trisha',
      });
      pdf.setFontSize(12);
      pdf.text('',14,22);
      pdf.save('cakeBill.pdf');

      this.router.navigate(['/product']);

    }


    
    
    );}
  
}