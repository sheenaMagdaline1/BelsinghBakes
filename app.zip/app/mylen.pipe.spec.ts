import { MylenPipe } from './mylen.pipe';

describe('MylenPipe', () => {
  it('create an instance', () => {
    const pipe = new MylenPipe();
    expect(pipe).toBeTruthy();
  });
});
